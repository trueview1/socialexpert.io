<?php

define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://mywebsite.com');
define('STYLESHEETS_URL', '//mywebsite.com');

error_reporting(1);
date_default_timezone_set('Asia/Kolkata');

return [
  'db' => [
    'name'    =>  '************',
    'host'    =>  'localhost',
    'user'    =>  '************',
    'pass'    =>  '************',
    'charset' =>  'utf8mb4' 
  ]
];
