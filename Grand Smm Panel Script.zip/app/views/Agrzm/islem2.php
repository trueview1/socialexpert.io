<div class="alert alert-dismissible alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>Sevgili @ <?php echo countRow(["table"=>"orders"]) ;?> 
        
        </strong> <br>Bakiyen azalmış gibi gözüküyor, sorunsuz hizmet alımı için bakiye yüklemeyi unutma.
      </div>